# Security policy / 安全政策

## 当前状态 / Current status

InkSight-GLHF 尚未公开首个测试版。最终版本支持范围将在发布时写入本文件；目前不要把后端 API `1.1.0` 当作项目安全支持版本。

InkSight-GLHF has not published its first test release. Version support will be recorded here at publication time; backend API `1.1.0` is not the project security-support version.

## 报告敏感问题 / Reporting sensitive issues

不要在公开 Issue、讨论、PR、日志或截图中披露可利用细节、密钥、数据库、真实 MAC、Wi-Fi、云端凭据、Admin Key 或个人数据。

仓库所有者尚未提供维护邮箱，也不能假定 GitHub 私密漏洞报告已经启用。公开仓库前必须二选一：

1. 启用 GitHub Private Vulnerability Reporting，并在仓库 Security 页面确认入口可用；或
2. 在此处加入由所有者控制的安全邮箱：`SECURITY_CONTACT_EMAIL_TO_BE_SET`。

如果发布后页面提供“Report a vulnerability”，请使用该私密入口。若没有任何私密渠道，请不要公开细节；等待维护者补充渠道，或仅通过已有的私密联系请求一个安全接收方式。一般公开 Issue 只适合不含敏感细节的安全加固建议。

Do not disclose exploit details, secrets, databases, real MAC addresses, Wi-Fi/cloud credentials, Admin Keys, or personal data in public issues, discussions, pull requests, logs, or screenshots.

No maintainer email has been supplied, and GitHub private vulnerability reporting must not be assumed to be enabled. Before publication, the owner must either enable and verify GitHub Private Vulnerability Reporting or replace `SECURITY_CONTACT_EMAIL_TO_BE_SET` above with an owner-controlled address. If neither private channel exists, do not publish details; request or wait for a private channel. Public issues are suitable only for non-sensitive hardening suggestions.

## 报告内容 / What to include privately

- 受影响版本、组件与环境；
- 最小复现步骤和影响；
- 已做的脱敏处理；
- 建议缓解方式（如有）。

Include the affected version/component/environment, minimal reproduction, impact, sanitization performed, and any suggested mitigation. No response-time or remediation deadline is promised in this test-stage policy.

## 使用方责任 / Operator responsibilities

- 公开仓库只使用示例配置；真实 `*.json` 私密配置、`.env`、数据库、状态与备份不得提交。
- OpenAI Admin Key 只保存在本机后端，不进入固件或公开载荷。
- 远程新闻源默认关闭，启用前逐源审查条款。
- 不要绕过固件目标、Flash 容量、分区、空白板或一次性确认检查。
- 定期轮换暴露过的任何凭据；仅删除 Git 历史中的字符串并不足以使密钥失效。

Use examples only in public, keep all real secrets/state out of Git, keep Admin Keys backend-local, review each remote source before enabling it, do not bypass flash safety checks, and rotate any exposed credential.
